#include "Writers.h"



Writers::Writers()
{
	LoadFromFile();
}


Writers::~Writers()
{
}
